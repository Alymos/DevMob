//
//  ViewController.swift
//  Morpion
//
//  Created by MOHSIN Aly Asgar on 07/04/2018.
//  Copyright © 2018 MOHSIN Aly Asgar. All rights reserved.
//


import UIKit
import AVFoundation

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{

    //Iniatialisation

    @IBOutlet weak var p1Icon: UIImageView!
    @IBOutlet weak var p2Icon: UIImageView!

    @IBOutlet weak var multiPlayerSwitch: UISwitch!

    let imagePicker = UIImagePickerController()

    @IBOutlet var gridButtons: [UIButton]!

    @IBOutlet weak var p1ScoreLabel: UILabel!
    @IBOutlet weak var p2ScoreLabel: UILabel!

    @IBOutlet weak var winnerLabel: UILabel!

    var img1 = UIImage(named: "cross")
    var img2 = UIImage(named: "nought")

    // Tableau de buttons
    var grid = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

    var currentPlayer : Int = 1

    // Score
    @IBOutlet weak var historyTextView: UITextView!

    // Initialisation des scores
    var p1Score : Int = 0
    var p2Score : Int = 0

    // Start game
    func start(){
        grid = [[0, 0, 0] , [0, 0, 0], [0, 0, 0]]


        for button in gridButtons{
            button.setImage(nil, for: .normal)
        }

        currentPlayer = 1
    }

    // Player 1
    @IBAction func btnX(_ sender: UIButton) {
        currentPlayer = 1
    }

    // Player 2
    @IBAction func btnO(_ sender: UIButton) {
        currentPlayer = 2
    }


    @IBAction func cellSelected(_ sender: UIButton) {

        let rowIndex = sender.tag / 3
        let colIndex = sender.tag % 3

        if grid[rowIndex][colIndex] != 0 {return}

        grid[rowIndex][colIndex] = currentPlayer

        //  Croix pour Player 1
        if currentPlayer == 1 {
            sender.setImage(img1, for: .normal)
        }
        // Rond pour Player 2
        else if currentPlayer == 2 {
            sender.setImage(img2, for: .normal)
        }

        //Affichage résultat
        let winner = winlose()
        switch winner {
        case 0:
            currentPlayer = (currentPlayer % 2) + 1
        case 1:
            // Victoire Player 1
            winnerLabel.text = "Player 1 a gagné!"
            alertWinner(playerName: "Player 1")
            p1Score += 1
            p1ScoreLabel.text = "Score: \(p1Score)"
            historyTextView.insertText("\nScore Player 1: \(p1Score)")

        case 2:
            // Victoire Player 2
            winnerLabel.text = "Player 2 a gangné!"
            alertWinner(playerName: "Player 2")
            p2Score += 1
            p2ScoreLabel.text = "Score: \(p2Score)"
            historyTextView.insertText("\nScore Player 2: \(p2Score)")
        default:
            winnerLabel.text = "\(winner) is not matched"
        }


        if multiPlayerSwitch.isOn == false{
            let (cellIndex, gridRowIndex, gridColIndex, p2Win) = whereToPlay()
            gridButtons[cellIndex].setImage(img2, for: .normal)
            grid[gridRowIndex][gridColIndex] = 2

            if p2Win == true {
                alertWinner(playerName: "Player 2")
            }
            currentPlayer = 1
        }
    }

    // Vérifie qui est le gagnant
    func winlose() -> Int {

        // Première ligne
        if grid[0][0] != 0 && grid[0][0] == grid[0][1] && grid[0][1] == grid[0][2] {
            return grid[0][0]
        }

        // Deuxième ligne
        if grid[1][0] != 0 && grid[1][0] == grid[1][1] && grid[1][1] == grid[1][2] {
            return grid[1][0]
        }

        // Troisième ligne
        if grid[2][0] != 0 && grid[2][0] == grid[2][1] && grid[2][1] == grid[2][2] {
            return grid[2][0]
        }

        // Première colonne
        if grid[0][0] != 0 && grid[0][0] == grid[1][0] && grid[1][0] == grid[2][0] {
            return grid[0][0]
        }

        // Deuxième colonne
        if grid[0][1] != 0 && grid[0][1] == grid[1][1] && grid[1][1] == grid[2][1] {
            return grid[0][1]
        }

        // Troisième colonne
        if grid[0][2] != 0 && grid[0][2] == grid[1][2] && grid[1][2] == grid[2][2] {
            return grid[2][2]
        }

        // Diagonale droite vers la gauche
        if grid[0][2] != 0 && grid[0][2] == grid [1][1] && grid[1][1] == grid[2][0] {
            return grid[2][0]
        }

        // Diagonale gauche vers la droite
        if grid[0][0] != 0 && grid[0][0] == grid[1][1] && grid[1][1] == grid[2][2]{
            return grid[2][2]
        }
        return 0
    }


    // Affichage du gagnant
    func alertWinner(playerName : String){
        let alertController = UIAlertController(title: "Alert", message: "\(playerName) a gagné!", preferredStyle: .alert)

        let okAction = UIAlertAction(title: "Ok", style: .default){
            (action) -> Void in self.start()
        }

        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }

    func whereToPlay() -> (Int, Int, Int, Bool){
        var index = -1
        var draw = 0
        var gridRowIndex = 0
        var gridColIndex = 0

        for row in 0 ... 2 {
            for col in 0 ... 2 {
                index = index + 1


                if grid[row][col] == 0
                {   grid[row][col] = 2
                    var i = winlose()

                    if i == 2
                    {
                        return (index, row, col, true)
                    }

                    grid[row][col] = 1
                    i = winlose()

                    if i == 1
                    {
                        return (index, row, col, false)
                    }

                    draw = index
                    gridRowIndex = row
                    gridColIndex = col

                    // Set the cell to empty
                    grid[row][col] = 0
                }
            }
        }

        return (draw, gridRowIndex, gridColIndex, false)
    }

    // Button Reset
    @IBAction func btnReset(_ sender: UIButton) {
        start()
    }



    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
