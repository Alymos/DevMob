package alymos.morpion;


import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button play;
    private Button score;
    private Button reprise;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Button Play
        this.play= (Button) findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent otherActivity= new Intent (getApplicationContext(), AccueilActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });


        // Button Reprendre
        this.reprise= (Button) findViewById(R.id.reprise);
        reprise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent otherActivity= new Intent (getApplicationContext(), AccueilActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        // Button Score
        this.score= (Button) findViewById(R.id.score);
        score.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent otherActivity= new Intent (getApplicationContext(), AccueilActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });
    }


}
